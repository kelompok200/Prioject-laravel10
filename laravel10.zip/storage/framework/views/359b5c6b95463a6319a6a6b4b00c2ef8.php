<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@latest/css/all.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('create.css')); ?>">
    <title>Edit Absen</title>
</head>
<body>
    <div class="container">
      <div class="card">
      <div class="card-header">
          <h2 class="mt-4 mb-4">ABSENSI KARYAWAN</h2>
          <form method="POST" action="<?php echo e(route('update',['id'=>$data->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
              <div class="alert alert-success" role="alert" id="myAlert">
              </div>
              <label for="">Kode Karyawan</label><br>
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><span class="fa-brands fa-codepen"></span></span>
                <input type="text" class="form-control" name="kode_karyawan" placeholder="Kode" value="<?php echo e($data->kode_karyawan); ?>" aria-label="Kode" id="input" aria-describedby="addon-wrapping">
              </div>
              <?php $__errorArgs = ['kode_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small style="color: red;"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <br>
              <label for="">Nama Karyawan</label><br>
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><span class="fa-solid fa-signature"></span></span>
                <input type="text" class="form-control" name="nama_karyawan" placeholder="Name" value="<?php echo e($data->nama_karyawan); ?>" aria-label="Name" id="input" aria-describedby="addon-wrapping">
              </div>
              <?php $__errorArgs = ['nama_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small style="color: red;"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <br>
              <label for="">Tanggal Absensi</label><br>
            <div class="input-group flex-nowrap">
              <span class="input-group-text" id="addon-wrapping"><span class="fa-solid fa-calendar"></span></span>
              <input type="date" class="form-control" name="tanggal_absensi" placeholder="" value="<?php echo e($data->tanggal_absensi); ?>" aria-label="" aria-describedby="addon-wrapping">
            </div><br>
              <label for="">Jam Masuk</label><br>
            <div class="input-group flex-nowrap">
            <span class="input-group-text" id="addon-wrapping"><span class="fa-solid fa-clock"></span></span>
            <input type="time" class="form-control" name="jam_masuk" placeholder="Masuk" value="<?php echo e($data->jam_masuk); ?>" aria-label="Masuk" id="input" aria-describedby="addon-wrapping">
            </div>
            <?php $__errorArgs = ['jam_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small style="color: red;"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
              <label for="">Jam Keluar</label><br>
            <div class="input-group flex-nowrap">
              <span class="input-group-text" id="addon-wrapping"><span class="fa-solid fa-clock"></span></span>
              <input type="text" class="form-control timepicker" name="jam_keluar" placeholder="Keluar" value="<?php echo e($data->jam_keluar); ?>" aria-label="Keluar" id="input" aria-describedby="addon-wrapping">
            </div>
            <?php $__errorArgs = ['jam_keluar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div><small style="color: red;"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <div class="col-12">
              <button type="submit" class="btn btn-primary mt-4" id="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('create.js')); ?>"></script>
  </div>
  </body>
  </html><?php /**PATH C:\belajar\resources\views/edit.blade.php ENDPATH**/ ?>