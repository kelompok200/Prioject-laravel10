<div class="navigasi">
    <ul>
        <a href="javascript: void(0);" class="icon" onclick="myfunction()"><span class="fa-solid fa-bars"></span></a>
    </ul>
    <ul>
        <a href=""><img src="<?php echo e(asset('github.jpg')); ?>" alt="" class=""><br><span class="ml-2">
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($s->name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </span></a>
    </ul>
    <ul>
        <a href="">Dashboard</a>
    </ul>
    <ul>
        <a href="">Data</a>
    </ul>
    <ul>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#logout">
            Log Out
        </button>
    </ul>
</div><?php /**PATH C:\belajar\resources\views/navbar/navbar.blade.php ENDPATH**/ ?>