<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Add Bootstrap Data Table css -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.10/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <title>Document</title>
    <style>
        body{
            display: flex;
            justify-content: center;
            align-items: center;
        }.login{
            padding: 60px;
            margin-top: 40px;
            width: 500px;
            max-height: 750px;
            border: solid 1px rgba(0, 0, 0, 0.445);
            border-radius: 6px;
            box-shadow: 4px 4px 0.5px silver;
        }
        input:not(input[type=checkbox]){
            width: 350px;
            height: 35px;
            margin: 5px;
            border-radius: 5px;
            font-size: 17px;
            border: solid 1px rgba(0, 0, 0, 0.315);
            font-family: 'Times New Roman', Times, serif;
        }label{
            margin: 5px;
            margin-left: 10px;
            font-size: 17px;
            pointer-events: none;
        }.submit{
            background: rgb(44, 44, 255);
            border: none;
            color: rgb(233, 233, 233);
        }h2{
            margin-bottom: 30px;
            text-align: center;
        }.submit:hover{
            background: blue;
        }input[type=checkbox]{
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="login">
        <h2>Register</h2><br>
        <form action="<?php echo e(route('inputsignin')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="nama">
                <label for="text">Nama</label><br>
                <input type="text" name="name" id="nama" style="font-size: 17px;">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><i class="fa-solid fa-triangle-exclamation"></i><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
            </div>
            <div class="Email">
                <label for="email">Email</label><br>
                <input type="email" name="email" id="" style="font-size: 17px;">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color:red;"><i class="fa-solid fa-triangle-exclamation"></i><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
            </div>
            <div class="password">
                <label for="password">Password</label><br>
                <input type="password" name="password" id="pass" style="font-size: 17px;">
                <input type="checkbox" name="" id="checkbox"><span> check</span>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br><small style="color:red;"><i class="fa-solid fa-triangle-exclamation"></i><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
            <div class="password">
                <label for="password">Confirm Password</label><br>
                <input type="password" name="verifikasi" id="confirm" style="font-size: 17px;">
                <input type="checkbox" name="" id="checkbox2"><span> check</span>
                <br>
            </div><br>
            <input type="submit" class="submit" value="Register">
        </form>
        <span>halaman login <a href="<?php echo e(route('login')); ?>">Log In</a></span>
    </div>
    <script src="<?php echo e(asset('check.js')); ?>"></script>
</body>
</html><?php /**PATH C:\belajar\resources\views/signin.blade.php ENDPATH**/ ?>