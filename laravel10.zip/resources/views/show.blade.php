<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="{{asset('show.css')}}">
    <title>Karyawan {{$data->nama_karyawan}}</title>
</head>
<body>
    <div class="container">
        <ul class="list-group list-group-flush">
            <li class="list-group-item mb-3"><label for="">Kode Karyawan  </label>: <span>{{$data->kode_karyawan}}</span></li>
            <li class="list-group-item mb-3"><label for="">Nama Karyawan  </label>: <span>{{$data->nama_karyawan}}</span></li>
            <li class="list-group-item mb-3"><label for="">Tanggal Absensi</label>: <span>{{$data->tanggal_absensi}}</span></li>
            <li class="list-group-item mb-3"><label for="">Jam Masuk      </label>: <span>{{$data->jam_masuk}}</span></li>
            <li class="list-group-item mb-3"><label for="">Jam Keluar     </label>: <span>{{$data->jam_keluar}}</span></li>
          </ul>
        <div>
            <a href="{{route('dasboard')}}" class="btn btn-primary">Back</a>
        </div>
    </div>
</body>
</html>